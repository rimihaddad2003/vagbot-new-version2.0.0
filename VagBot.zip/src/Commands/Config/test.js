module.exports = {
  name: "test1",
  desc: "Testing cmds",
  category: "hidden",
  perms: ["ADMINISTRATOR"],
  cooldown: 10000,
  run: (client, message, args) => {

  },
};
